해당 폴더의 파일은 
pgsHZz.apk 파일을 디컴파일 한후

kill-classes.dex 파일, kill-classes2.dex 파일을 
classes2.dex , classes3.dex파일로 복호화하여 
리패키징하였다.