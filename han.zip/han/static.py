import requests
import json
from requests_toolbelt.multipart.encoder import MultipartEncoder

# 서버 및 파일 지정 API키
Server = "http://127.0.0.1:8000"
FILE = r"C:\Users\han31\Downloads\repacking\repacking\pgsHZz.apk"

APIKEY = '2f93666414f0b60e9e02f086c7bc94baf7f71103d37854814307dd56621e578b'

#### 파일 업로드 ####

def upload():
    """Upload File"""
    print("파일을 업로드 하고 있습니다.")
    multipart_data = MultipartEncoder(
        fields={'file': (FILE, open(FILE, 'rb'),'application/octet-stream')}
        )
    headers = {
        'Content-Type': multipart_data.content_type, 'Authorization': APIKEY}
    response = requests.post(
        Server + '/api/v1/upload', data=multipart_data, headers=headers)
    print(response.text)
    return response.text

# 업로드한 파일에 대해 정적 분석을 수행하는 함수
def scan(data):
    """Scan the file"""
    print("Scanning file")
    
    # JSON 형식의 문자열을 파이썬 객체로 변환 (파일 해시 등 정보 추출)
    post_dict = json.loads(data)
    
    # API 요청 헤더 설정
    headers = {'Authorization': APIKEY}
    
    # POST 요청으로 정적 분석 실행 (파일 해시 정보 사용)
    response = requests.post(Server + '/api/v1/scan', data=post_dict, headers=headers)
    print(response.text)  # 분석 결과 출력

# PDF 보고서를 생성하고 다운로드하는 함수
def pdf(data):
    """Generate PDF Report"""
    print("Generate PDF report")
    
    # API 요청 헤더 설정
    headers = {'Authorization': APIKEY}
    
    # 보고서 생성에 필요한 해시 값을 JSON에서 추출하여 데이터로 설정
    data = {"hash": json.loads(data)["hash"]}
    
    # POST 요청으로 PDF 보고서를 다운로드 (stream=True는 파일로 받을 때 필요)
    response = requests.post(Server + '/api/v1/download_pdf', data=data, headers=headers, stream=True)
    
    # 응답을 읽어 'report.pdf' 파일로 저장
    with open(r"C:\Users\han31\Desktop\sandbox\report\report.pdf", 'wb') as flip:
        for chunk in response.iter_content(chunk_size=1024):  # 청크 단위로 다운로드
            if chunk:
                flip.write(chunk)
    print("Report saved as report.pdf")  # 저장 완료 메시지 출력

# JSON 형식의 보고서를 생성하고 결과를 출력하는 함수
def json_resp(data):
    """Generate JSON Report"""
    print("Generate JSON report")
    
    # API 요청 헤더 설정
    headers = {'Authorization': APIKEY}
    
    # 보고서 생성에 필요한 해시 값을 JSON에서 추출하여 데이터로 설정
    data = {"hash": json.loads(data)["hash"]}
    
    # POST 요청으로 JSON 보고서 생성 요청
    response = requests.post(Server + '/api/v1/report_json', data=data, headers=headers)
    print(response.text)  # JSON 보고서 출력

# 분석 데이터를 삭제하는 함수
def delete(data):
    """Delete Scan Result"""
    print("Deleting Scan")
    
    # API 요청 헤더 설정
    headers = {'Authorization': APIKEY}
    
    # 삭제할 데이터의 해시 값 설정
    data = {"hash": json.loads(data)["hash"]}
    
    # POST 요청으로 특정 분석 결과 삭제 요청
    response = requests.post(Server+ '/api/v1/delete_scan', data=data, headers=headers)
    print(response.text)  # 삭제 결과 출력

# 전체 프로세스 실행: 파일 업로드, 스캔, JSON 및 PDF 보고서 생성, 삭제
RESP = upload()  # 파일 업로드 후 해시 ID 반환
scan(RESP)       # 업로드한 파일로 정적 분석 수행
json_resp(RESP)  # JSON 형식의 분석 결과 출력
pdf(RESP)        # PDF 보고서 생성 및 저장
delete(RESP)     # 분석 결과 삭제