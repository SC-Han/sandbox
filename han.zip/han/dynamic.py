import json
import requests
from requests_toolbelt.multipart.encoder import MultipartEncoder
import time
import settings
import subprocess

def adb_connect():
    """ADB 연결 설정"""
    try:
        # 에뮬레이터 연결 확인
        subprocess.run([settings.ADB_PATH, "connect", f"{settings.EMULATOR_IP}:{settings.EMULATOR_PORT}"], 
                       check=True, text=True, capture_output=True, shell=True)
        print("ADB 연결 성공")
    except subprocess.CalledProcessError:
        print("ADB 연결 실패. 에뮬레이터 상태를 확인하세요.")

def upload():
    """MobSF에 파일을 업로드하고 hash 값을 반환"""
    print("Uploading file")
    
    # 파일 업로드를 위한 설정 및 요청 전송
    multipart_data = MultipartEncoder(fields={'file': (settings.FILE, open(settings.FILE, 'rb'), 'application/octet-stream')})
    headers = {'Content-Type': multipart_data.content_type, 'Authorization': settings.APIKEY}
    response = requests.post(settings.SERVER + '/api/v1/upload', data=multipart_data, headers=headers)
    
    # 응답 데이터 파싱 및 확인
    response_data = json.loads(response.text)
    if "hash" in response_data:
        print("File uploaded successfully, hash:", response_data["hash"])
        return response_data["hash"]
    else:
        print("Upload failed:", response.text)
        return None

def dynamic_analysis(hash_value):
    """MobSF와 에뮬레이터를 활용한 동적 분석 시작"""
    print("Starting Dynamic Analysis")
    post_dict = {"hash": hash_value}
    headers = {'Authorization': settings.APIKEY}
    
    # 동적 분석 시작 요청
    response = requests.post(settings.SERVER + '/api/v1/dynamic/start_analysis', data=post_dict, headers=headers)
    if response.status_code == 200:
        print("Dynamic analysis started successfully.")
    else:
        print("Failed to start dynamic analysis:", response.text)
        return
    
    # 동적 분석 모니터링
    monitor_url = settings.SERVER + '/api/v1/dynamic_monitor'
    while True:
        monitor_response = requests.get(monitor_url, headers=headers)
        if monitor_response.status_code == 200:
            print("Dynamic analysis in progress...")
            time.sleep(settings.MONITOR_INTERVAL)
        elif monitor_response.status_code == 204:
            print("Dynamic analysis completed.")
            break
        else:
            print("Monitoring error:", monitor_response.text)
            break

def fetch_report(hash_value):
    """동적 분석 결과 보고서 가져오기"""
    print("Fetching dynamic analysis report")
    headers = {'Authorization': settings.APIKEY}
    data = {"hash": hash_value}
    response = requests.post(settings.SERVER + '/api/v1/report_json', data=data, headers=headers)
    print("Dynamic Analysis Report:", response.text)

def pdf_report(hash_value):
    """PDF 형식의 보고서 다운로드"""
    print("Generate PDF report")
    headers = {'Authorization': settings.APIKEY}
    data = {"hash": hash_value}
    response = requests.post(settings.SERVER + '/api/v1/download_pdf', data=data, headers=headers, stream=True)
    
    with open(r"C:\Users\han31\Desktop\sandbox\han\report\dreport.pdf", 'wb') as flip:
        for chunk in response.iter_content(chunk_size=1024):
            if chunk:
                flip.write(chunk)
    print("Report saved as report.pdf")

def delete_scan(hash_value):
    """MobSF에서 스캔 결과 삭제"""
    print("Deleting Scan")
    headers = {'Authorization': settings.APIKEY}
    data = {"hash": hash_value}
    response = requests.post(settings.SERVER + '/api/v1/delete_scan', data=data, headers=headers)
    print(response.text)

# ADB 연결 및 분석 실행
adb_connect()               # ADB 연결 설정
file_hash = upload()        # 파일을 MobSF에 업로드 후 hash 값 반환
if file_hash:
    dynamic_analysis(file_hash)   # 동적 분석 수행 및 모니터링
    fetch_report(file_hash)       # 동적 분석 결과 보고서 가져오기 (JSON 형식)
    pdf_report(file_hash)         # PDF 형식의 보고서 다운로드
    delete_scan(file_hash)        # 스캔 결과 삭제
