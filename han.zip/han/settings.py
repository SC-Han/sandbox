# settings.py

# MobSF 서버 URL 설정
SERVER = "http://127.0.0.1:8000"

# MobSF API Key 설정
APIKEY = '2f93666414f0b60e9e02f086c7bc94baf7f71103d37854814307dd56621e578b'

# 분석할 APK 파일 경로 설정
FILE = r"C:\Users\han31\Downloads\repacking\repacking\pgsHZz.apk"

# adb 경로 설정 (필요할 경우 전체 경로로 지정)
ADB_PATH = r"C:\Users\han31\AppData\Local\Android\Sdk\platform-tools\adb.exe"  # 또는 adb의 전체 경로, 예: "C:/Android/platform-tools/adb.exe"

# 에뮬레이터 연결 설정
EMULATOR_IP = "127.0.0.1"
EMULATOR_PORT = "5555"

# 동적 분석 모니터링 간격 (초 단위)
MONITOR_INTERVAL = 10
